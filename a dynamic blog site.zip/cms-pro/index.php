<!-- Database Connection -->
<?php //include "includes/db.php"; ?>

<?php include "lib/config.php"; ?>
<?php include "lib/database.php"; ?>

<!-- Header File -->
<?php include "includes/header.php"; ?>

<!-- Navigation -->
<?php include "includes/navigation.php"; ?>

<?php include "functions/format.php"; ?>
    
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                
                <!-- <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1> -->
<?php
    $db = new Database();
    $query = "SELECT * FROM posts";
    $read = $db->select($query);
?>


<?php
    $fm = new format();
?>
<?php if ($read) {

    // $query = "SELECT * FROM posts";
    
    // $select_all_posts_query = mysqli_query($db_connect, $query);
    
    while( $row = $read->fetch_assoc() ){

        $post_id          = $row['post_id'];
        $post_title       = $row['post_title'];
        $post_author      = $row['post_author'];
        $post_time        = $row['post_date'];
        $post_thumbnail   = $row['post_thumbnail'];
        $post_desc        = $row['post_description'];
    
?>

            <!-- Blog Post -->

            <div class="blog-post">
                <h2>
                    <a href="post.php?id=<?php echo $post_id;?>"><?php echo $post_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href="index.php"><?php echo $post_author; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $fm->formatDate($post_time); ?></p>
                <hr>
                <img class="img-responsive img-fluid" width="70%" src="assets/images/posts/<?php echo $post_thumbnail; ?>" alt="">
                <hr>
                <p><?php echo $fm->shortText($post_desc, 200); ?></p>

                <a class="btn btn-primary" href="post.php?id=<?php echo $post_id;?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
                
            </div>


        <!-- while loop end -->
        <?php
            } }  
        ?>

        <!-- Pagination start -->
        <?php echo "<span class='pagination' ><a href='index.php?page=1'>".'First Page'."</a>"; ?>
        1, 2, 3
        <?php echo "<a href='index.php?page=1'>".'Last Page'."</span>"; ?>
        <!-- Pagination end -->

            </div>

            <!-- Sidebar -->
            <?php include "includes/sidebar.php"; ?>

        </div>
        <!-- /.row -->

    <!-- Footer -->
    <?php include "includes/footer.php"; ?>