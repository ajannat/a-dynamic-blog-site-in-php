<?php 
	include "includes/header.php";
	include "includes/navbar.php";

?>


<?php
    $db = new Database();
    $query = "SELECT * FROM posts";
    $read = $db->select($query);
?>

	<div class="container-fluid view-all-posts">
		<h1>All Posts <a id="add-new-btn" href="add-new-post.php">(Add New)</a></h1>

		<dvi class="users_table">
			<table class="table table-hover">
				<thead class="thead-light">
					<tr>
						<th width="16%">Post title</th>
						<th width="10%">Post Category</th>
						<th width="10%">Post Author</th>
						<th width="34%">Post Description</th>
						<th width="10%">Post Thumbnail</th>
						<th width="10%">Update Post</th>
						<th width="10%">Delete Post</th>
					</tr>
				</thead>

				<?php

			    $query = "SELECT * FROM posts";
			    
			    $select_all_posts_query = mysqli_query($db_connect, $query);
			    
			    while( $row = mysqli_fetch_assoc($select_all_posts_query) ){

			        $post_title    = $row['post_title'];
			        $post_cat_id   = $row['post_cat'];
			        $post_author   = $row['post_author'];
			        $post_desc     = $row['post_description'];
			        $post_thumb    = $row['post_thumbnail'];

			        $post_cat_all = "SELECT * FROM categories where cat_id = '$post_cat_id'";
			        $cat_query = mysqli_query($db_connect, $post_cat_all);
			    
			    	$row = mysqli_fetch_assoc($cat_query);
			    	$post_cat = $row['cat_name'];
			    
				?>

				<tr>
					<td><p><?php echo $post_title; ?></p></td>
					<td><p><?php echo $post_cat; ?></p></td>
					<td><p><?php echo $post_author; ?></p></td>
					<td><p><?php echo $post_desc; ?></p></td>
					<td><img src="../assets/images/posts/<?php echo $post_thumb; ?>" width="100" ></td>

					<!-- Edit post -->
					<td><form method="POST" action="edit-post.php">
					    <a class=" text-white" href="edit-post.php?edit_post_id=<?php echo $row['post_id']; ?>"><div class="btn btn-primary" id="edit-delete-btn">Edit</div>
					    </a>
  						
					</form></td>

					<!-- Delete post -->
					
					<td>
						<a onclick="return confirm('Are you sure?');">
							<form id="delete" method="post" action="">
					        <input type="hidden" name="delete_rec_id" value="<?php echo $row['post_id']; ?>"/> 
					        <input type="submit" name="delete" class="btn btn-danger" id="edit-delete-btn" value="Delete"/>    

				        	</form>
			        	</a>
			    	</td>
				</tr>


			<?php } ?>

			<?php
				if(isset($_POST['delete'])){
			       $id = $_POST['delete_rec_id'];  
			       $query = "DELETE FROM posts WHERE post_id='$id'"; 
			       $delete_post = mysqli_query($db_connect, $query);
			       if($delete_post)
						header('Location: view-all-posts.php');
					else
						echo "Failed!!!";
			    }
				
			?>

			</table>
		</div>

	</div>



<?php 
	include "includes/footer.php";
?>
