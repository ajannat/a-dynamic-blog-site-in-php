function validate() {
      
     if( document.validate_form.post_title.value == "" ) {
        alert( "Please provide your name!" );
        document.validate-form.Name.focus() ;
        return false;
     }
     if( document.validate-form.post_cat.value == "" ) {
        alert( "Please provide your Email!" );
        document.validate-form.post_cat.focus() ;
        return false;
     }
     if( document.validate-form.post_author.value == "" ) {
        alert( "Please provide your country!" );
        return false;
     }
     return( true );
}