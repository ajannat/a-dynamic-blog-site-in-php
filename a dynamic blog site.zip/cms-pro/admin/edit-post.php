<?php 
	include "includes/header.php";
	include "includes/navbar.php";
?>



<?php 

	if(isset($_GET['edit_post_id']) && $_GET['edit_post_id'] !== ''){
	  $post_id = $_GET['edit_post_id'];
	  //echo $post_id;
	} else {
	  echo "failed";
	}

	$query = "SELECT * FROM posts where post_id = '$post_id'";
	$selected_post = mysqli_query($db_connect, $query);
	while( $row = mysqli_fetch_assoc($selected_post) ){
        $post_title    = $row['post_title'];
        $post_cat      = $row['post_cat'];
        $post_author   = $row['post_author'];
        $post_desc     = $row['post_description'];
        $post_thumb    = $row['post_thumbnail'];
        $post_pic	   = $row['post_thumbnail'];
	}


	if(isset($_POST['update_post'])){

		$post_title     = $_POST['post_title'];
		$post_cat       = $_POST['post_cat'];
		$post_author    = $_POST['post_author'];
		$post_desc      = $_POST['post_desc'];
		$post_thumbnail = $_FILES['post_thumbnail']['name'];
		$post_img_tmp   = $_FILES['post_thumbnail']['tmp_name'];

		move_uploaded_file($post_img_tmp, '../assets/images/posts/'.$post_thumbnail);

		date_default_timezone_set('Asia/Dhaka');
		$post_date      = date('y-m-d h:i:s A');
		$post_view      = 1;


		if($_FILES["post_thumbnail"]["error"]){
			$post_thumbnail = $post_pic;
		}

		$query = "UPDATE posts SET post_title = '$post_title', post_cat = '$post_cat', post_author = '$post_author', post_description = '$post_desc', post_thumbnail = '$post_thumbnail'
				WHERE post_id = '$post_id'";

		
		$insert_new_post = mysqli_query($db_connect, $query);
		if($insert_new_post)
			//echo "hi there";
			header('Location: view-all-posts.php');
		else
			echo "Failed!!!";
	}

?>

	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<div class="add-new-post">
					<h2>Update post</h2>
					<form method="POST" enctype="multipart/form-data" name="validate_form">
						<div class="form-group">
							<input type="text" name="post_title" class="form-control" placeholder="Post Title*" value="<?php echo "$post_title"; ?>" required>
						</div>
						<div class="form-group">
							<input type="text" name="post_cat" class="form-control" placeholder="Post Category*" value="<?php echo "$post_cat"; ?>" required>
						</div>
						<div class="form-group">
							<input type="text" name="post_author" class="form-control" placeholder="Post Author*" value="<?php echo "$post_author"; ?>" required>
						</div>
						<div class="form-group">
							<textarea name="post_desc" rows="10" class="form-control" placeholder="Post Description*" required> <?php echo "$post_desc"; ?> </textarea>
						</div>
						<div class="form-group">
						    <input type="file" class="form-control-file" name="post_thumbnail" value="<?php echo "$post_thumbnail"; ?>">
  						</div>
						<div class="form-group">
						    <input type="submit" class="btn btn-primary" name="update_post" value="Update">
  						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php 
	include "includes/footer.php";
?>
