<?php 
	include "includes/header.php";
	include "includes/navbar.php";

?>

	<div class="container view-all-category">
		<h1>All Category <a id="add-new-btn" href="add-new-category.php">Add New</a></h1>

		<div class="users_table text-center">
			<table class="table">
				<tr>
					<th>Category Name</th>
					<th>Delete Category</th>
				</tr>

				<?php

			    $query = "SELECT * FROM categories";
			    
			    $select_all_category = mysqli_query($db_connect, $query);
			    
			    while( $row = mysqli_fetch_assoc($select_all_category) ){

			        $cat_id    = $row['cat_id'];
			        $cat_name  = $row['cat_name'];
			    
				?>

				<tr>
					<td><p><?php echo $cat_name; ?></p></td>

					<!-- Delete category -->
					
					<td>
						<a onclick="return confirm('Are you sure?');">
							<form id="delete" method="post" action="">
					        <input type="hidden" name="delete_rec_id" value="<?php echo $row['cat_id']; ?>"/> 
					        <input type="submit" name="delete" class="btn btn-danger" id="edit-delete-btn" value="Delete"/>    

				        	</form>
			        	</a>
			    	</td>
				</tr>


			<?php } ?>

			<?php
				if(isset($_POST['delete'])){
			       $id = $_POST['delete_rec_id'];  
			       $query = "DELETE FROM categories WHERE cat_id='$id'"; 
			       $delete_post = mysqli_query($db_connect, $query);
			       if($delete_post)
						header('Location: view-all-category.php');
					else
						echo "Failed!!!";
			    }
				
			?>

			</table>
		</div>

	</div>



<?php 
	include "includes/footer.php";
?>
