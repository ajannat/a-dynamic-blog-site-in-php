<?php 
	include "includes/header.php";
	include "includes/navbar.php";

?>

	<div class="container-fluid">
		<h1>View All Users</h1>

		<div class="users_table">
			<table class="table">
				<tr>
					<th>User ID</th>
					<th>Name</th>
					<th>Email</th>
					<th>Phone</th>
				</tr>

				<?php

			    $query = "SELECT * FROM users";
			    
			    $select_all_posts_query = mysqli_query($db_connect, $query);
			    
			    while( $row = mysqli_fetch_assoc($select_all_posts_query) ){

			        $user_id       = $row['user_id'];
			        $user_name     = $row['user_name'];
			        $user_email    = $row['user_email'];
			        $user_phone    = $row['user_phone'];
			    
				?>

				<tr>
					<td><p><?php echo $user_id; ?></p></td>
					<td><p><?php echo $user_name; ?></p></td>
					<td><p><?php echo $user_email; ?></p></td>
					<td><p><?php echo $user_phone; ?></p></td>
				</tr>

			<?php } ?>

			</table>
		</div>

	</div>


<?php 
	include "includes/footer.php";
?>
