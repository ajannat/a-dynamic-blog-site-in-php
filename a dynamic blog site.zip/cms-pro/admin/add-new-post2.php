<?php 
	include "includes/header.php";
	include "includes/navbar.php";
?>



<?php 

	if(isset($_POST['create_post'])){

		$post_title     = $_POST['post_title'];
		$post_cat       = $_POST['post_cat'];
		$post_author    = $_POST['post_author'];
		$post_desc      = $_POST['post_desc'];
		$post_thumbnail = $_FILES['post_thumbnail']['name'];
		$post_img_tmp   = $_FILES['post_thumbnail']['tmp_name'];

		move_uploaded_file($post_img_tmp, '../assets/images/posts/'.$post_thumbnail);

		date_default_timezone_set('Asia/Dhaka');
		$post_date      = date('y-m-d h:i:s A');
		$post_view      = 1;


		$query = "INSERT INTO posts (post_id, post_title, post_cat, post_author, post_description, post_thumbnail, post_date) 
			VALUES ('', '$post_title', '$post_cat', '$post_author', '$post_desc', '$post_thumbnail', '$post_date')";

		$insert_new_post = mysqli_query($db_connect, $query);
		if($insert_new_post)
			//echo "hi there";
			header('Location: view-all-posts.php');
		else
			echo "Failed!!!";
	}
?>


	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<div class="add-new-post">
					<h2>Create a new post</h2>
					<form method="POST" enctype="multipart/form-data" name="validate_form">
						<div class="form-group">
							<input type="text" name="post_title" class="form-control" placeholder="Post Title*" required>
						</div>
						<div class="form-group">
							<input type="text" name="post_cat" class="form-control" placeholder="Post Category*" required>
						</div>
						<div class="form-group">
							<input type="text" name="post_author" class="form-control" placeholder="Post Author*" required>
						</div>
						<div class="form-group">
							<textarea name="post_desc" rows="10" class="form-control" placeholder="Post Description*" required></textarea>
						</div>
						<div class="form-group">
						    <input type="file" class="form-control-file" name="post_thumbnail" id="exampleFormControlFile1" required>
  						</div>
						<div class="form-group">
						    <input type="submit" class="btn btn-primary" name="create_post" value="Add Post">
  						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php 
	include "includes/footer.php";
?>
