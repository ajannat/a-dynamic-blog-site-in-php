<?php 
	include "includes/header.php";
	include "includes/navbar.php";
?>



<?php 

	if(isset($_POST['create_cat'])){

		$cat_name     = $_POST['cat_name'];


		$query = "INSERT INTO categories (cat_id, cat_name) 
			VALUES ('', '$cat_name')";

		$insert_new_cat = mysqli_query($db_connect, $query);
		if($insert_new_cat)
			//echo "hi there";
			header('Location: view-all-category.php');
		else
			echo "Failed!!!";
	}
?>


	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<div class="add-new-post">
					<h2>Add a new category</h2>
					<form method="POST" enctype="multipart/form-data" name="validate_form">
						<div class="form-group">
							<input type="text" name="cat_name" class="form-control" placeholder="Category Name*" required>
						</div>
						<div class="form-group">
						    <input type="submit" class="btn btn-primary" name="create_cat" value="Add Category">
  						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php 
	include "includes/footer.php";
?>
